package com.zy.ai;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(8, 10, 15);
    private static final int PANEL = Color.rgb(23, 27, 36);
    private static final int ACCENT = Color.rgb(108, 229, 221);
    private static final int MUTED = Color.rgb(157, 166, 180);
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final List<JSONObject> messages = new ArrayList<>();
    private LinearLayout chatList;
    private ScrollView scroll;
    private EditText entry;
    private Button sendButton;
    private TextView status;
    private String endpoint;
    private String model;
    // Kept only in RAM: never put the token in APK source, Gradle, or preferences.
    private String apiKey = "";
    private boolean busy = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        SharedPreferences prefs = getSharedPreferences("settings", MODE_PRIVATE);
        endpoint = prefs.getString("endpoint", "https://api.openai.com/v1/chat/completions");
        model = prefs.getString("model", "gpt-4o-mini");
        render();
        appendBubble("欢迎使用 ZY AI。点击右上角「API 设置」，填写完整接口地址、模型名称和 API Key，即可开始聊天。", false);
        showSettings();
    }

    private int dp(float value) { return (int) (getResources().getDisplayMetrics().density * value + 0.5f); }

    private GradientDrawable bg(int color, float radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextColor(color); t.setTextSize(size);
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setAllCaps(false); b.setText(label);
        b.setTextSize(13); b.setTextColor(Color.BLACK);
        b.setBackgroundTintList(ColorStateList.valueOf(ACCENT));
        return b;
    }

    private void render() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        root.setPadding(dp(12), dp(12), dp(12), dp(8));
        setContentView(root);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setOrientation(LinearLayout.HORIZONTAL);
        TextView name = text("ZY AI", 25, Color.WHITE);
        name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        header.addView(name, new LinearLayout.LayoutParams(0, dp(52), 1));
        Button config = button("API 设置");
        header.addView(config, new LinearLayout.LayoutParams(dp(105), dp(48)));
        config.setOnClickListener(v -> showSettings());
        root.addView(header);

        LinearLayout subHeader = new LinearLayout(this);
        subHeader.setGravity(Gravity.CENTER_VERTICAL);
        status = text("尚未连接", 12, MUTED);
        subHeader.addView(status, new LinearLayout.LayoutParams(0, dp(37), 1));
        TextView clear = text("新对话  ＋", 13, ACCENT);
        clear.setPadding(dp(10), dp(6), dp(4), dp(6));
        clear.setOnClickListener(v -> {
            if (busy) { Toast.makeText(this, "请等待当前回答完成", Toast.LENGTH_SHORT).show(); return; }
            messages.clear(); chatList.removeAllViews();
            appendBubble("新对话已开始。", false);
        });
        subHeader.addView(clear);
        root.addView(subHeader);

        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        chatList = new LinearLayout(this);
        chatList.setPadding(0, dp(12), 0, dp(10));
        chatList.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(chatList);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout bottom = new LinearLayout(this);
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        bottom.setPadding(dp(10), dp(6), dp(4), dp(6));
        bottom.setBackground(bg(PANEL, 18));
        entry = new EditText(this);
        entry.setTextColor(Color.WHITE);
        entry.setHintTextColor(MUTED);
        entry.setHint("输入消息...");
        entry.setTextSize(15);
        entry.setBackgroundColor(Color.TRANSPARENT);
        entry.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        entry.setMaxLines(4);
        bottom.addView(entry, new LinearLayout.LayoutParams(0, -2, 1));
        sendButton = button("发送");
        bottom.addView(sendButton, new LinearLayout.LayoutParams(dp(73), dp(48)));
        sendButton.setOnClickListener(v -> sendMessage());
        root.addView(bottom, new LinearLayout.LayoutParams(-1, -2));
    }

    private void appendBubble(String message, boolean self) {
        LinearLayout line = new LinearLayout(this);
        line.setOrientation(LinearLayout.VERTICAL);
        line.setGravity(self ? Gravity.RIGHT : Gravity.LEFT);
        line.setPadding(0, dp(5), 0, dp(5));
        TextView bubble = text(message, 15, self ? Color.BLACK : Color.WHITE);
        bubble.setBackground(bg(self ? ACCENT : PANEL, 16));
        bubble.setPadding(dp(14), dp(11), dp(14), dp(11));
        bubble.setMaxWidth(getResources().getDisplayMetrics().widthPixels - dp(70));
        line.addView(bubble);
        chatList.addView(line, new LinearLayout.LayoutParams(-1, -2));
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private EditText field(LinearLayout panel, String title, String value, boolean password) {
        TextView label = text(title, 13, MUTED);
        label.setPadding(dp(3), dp(12), 0, dp(4));
        panel.addView(label);
        EditText input = new EditText(this);
        input.setText(value);
        input.setSingleLine(true);
        input.setTextSize(14);
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(MUTED);
        input.setPadding(dp(12), dp(12), dp(12), dp(12));
        input.setBackground(bg(PANEL, 10));
        input.setInputType(password ? (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD) : InputType.TYPE_CLASS_TEXT);
        panel.addView(input, new LinearLayout.LayoutParams(-1, dp(49)));
        return input;
    }

    private void showSettings() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18), dp(8), dp(18), dp(2));
        EditText urlField = field(panel, "完整 API 地址（HTTPS）", endpoint, false);
        EditText modelField = field(panel, "模型名称", model, false);
        EditText keyField = field(panel, "API Key（本次运行期间有效）", "", true);
        keyField.setHint(TextUtils.isEmpty(apiKey) ? "输入你的 API Key" : "已输入；留空则保持不变");
        TextView caution = text("密钥只保存在运行内存，不写入 APK 或本地配置。发布多人使用版本请改为后端代理。", 12, MUTED);
        caution.setPadding(0, dp(12), 0, 0);
        panel.addView(caution);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("连接 AI 接口")
                .setView(panel)
                .setNegativeButton("取消", (d, which) -> {})
                .setPositiveButton("保存", null)
                .create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String u = urlField.getText().toString().trim();
            String m = modelField.getText().toString().trim();
            String k = keyField.getText().toString().trim();
            android.net.Uri uri = android.net.Uri.parse(u);
            if (!"https".equalsIgnoreCase(uri.getScheme()) || TextUtils.isEmpty(uri.getHost())) {
                urlField.setError("请输入以 https:// 开头的完整接口地址"); return;
            }
            if (m.isEmpty()) { modelField.setError("请输入模型名称"); return; }
            endpoint = u; model = m;
            if (!k.isEmpty()) apiKey = k;
            getSharedPreferences("settings", MODE_PRIVATE).edit()
                    .putString("endpoint", endpoint).putString("model", model).apply();
            status.setText(TextUtils.isEmpty(apiKey) ? "等待 API Key" : "已配置 · " + model);
            dialog.dismiss();
        }));
        dialog.getWindow();
        dialog.show();
    }

    private void sendMessage() {
        if (busy) return;
        String question = entry.getText().toString().trim();
        if (question.isEmpty()) return;
        if (apiKey.isEmpty()) { showSettings(); Toast.makeText(this, "先填写 API Key", Toast.LENGTH_SHORT).show(); return; }
        entry.setText(""); appendBubble(question, true);
        try {
            messages.add(new JSONObject().put("role", "user").put("content", question));
        } catch (Exception e) { appendBubble("创建请求失败", false); return; }
        JSONArray snapshot = new JSONArray();
        // Last 20 messages to limit cost/context size.
        int start = Math.max(0, messages.size() - 20);
        for (int i = start; i < messages.size(); i++) snapshot.put(messages.get(i));
        busy = true; sendButton.setEnabled(false); status.setText("AI 正在回复...");
        final String currentUrl = endpoint, currentModel = model, currentKey = apiKey;
        worker.execute(() -> {
            try {
                String reply = request(currentUrl, currentModel, currentKey, snapshot);
                runOnUiThread(() -> {
                    try { messages.add(new JSONObject().put("role", "assistant").put("content", reply)); }
                    catch (Exception ignored) {}
                    appendBubble(reply, false);
                    finishRequest();
                });
            } catch (Exception e) {
                final String error = e.getMessage() == null ? "未知网络错误" : e.getMessage();
                runOnUiThread(() -> {
                    // Failed prompt removed from request history (visible bubble remains).
                    if (!messages.isEmpty()) messages.remove(messages.size() - 1);
                    appendBubble("请求失败：" + error, false);
                    finishRequest();
                });
            }
        });
    }

    private void finishRequest() {
        busy = false; sendButton.setEnabled(true);
        status.setText("已配置 · " + model);
    }

    private String request(String apiUrl, String name, String key, JSONArray history) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(apiUrl).openConnection();
        try {
            con.setRequestMethod("POST");
            con.setConnectTimeout(20000);
            con.setReadTimeout(60000);
            con.setDoOutput(true);
            con.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            con.setRequestProperty("Authorization", "Bearer " + key);
            JSONObject payload = new JSONObject().put("model", name).put("messages", history).put("stream", false);
            byte[] data = payload.toString().getBytes(StandardCharsets.UTF_8);
            try (OutputStream out = con.getOutputStream()) { out.write(data); }
            int code = con.getResponseCode();
            InputStream stream = code >= 200 && code < 300 ? con.getInputStream() : con.getErrorStream();
            String raw = readText(stream);
            if (code < 200 || code >= 300) {
                String summary = raw.length() > 250 ? raw.substring(0, 250) + "..." : raw;
                throw new Exception("HTTP " + code + " / " + summary);
            }
            JSONObject result = new JSONObject(raw);
            JSONArray choices = result.optJSONArray("choices");
            if (choices == null || choices.length() == 0) throw new Exception("响应中没有 choices；请检查接口格式");
            JSONObject msg = choices.getJSONObject(0).optJSONObject("message");
            if (msg == null) throw new Exception("响应中没有 message");
            String response = msg.optString("content", "");
            if (response.isEmpty()) throw new Exception("模型返回空内容");
            return response;
        } finally { con.disconnect(); }
    }

    private String readText(InputStream stream) throws Exception {
        if (stream == null) return "";
        StringBuilder result = new StringBuilder();
        try (BufferedReader in = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line).append('\n');
                if (result.length() > 1000000) throw new Exception("响应过大");
            }
        }
        return result.toString();
    }

    @Override protected void onDestroy() {
        worker.shutdownNow();
        apiKey = "";
        super.onDestroy();
    }
}
