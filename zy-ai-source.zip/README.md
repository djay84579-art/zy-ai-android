# ZY AI — Android native API chat client

原生 Java Android APP 示例：聊天、设置完整 HTTPS `chat/completions` 接口地址、模型、API Key、保留当前会话。

支持 OpenAI 风格 `/v1/chat/completions` 非流式 JSON 协议；其他 API 协议需要修改 `MainActivity.java`。

安全约束：API Key 仅在运行内存，不存盘；若要公开给其他人使用，请把接口调用放到自己的后端并做用户鉴权/限流。

## 纯安卓手机 GitHub Actions 编译

1. 在 GitHub 建立公开或私有空仓库。建议仓库名 `zy-ai-android`。
2. 上传 `zy-ai-source.zip` 到仓库根目录（此 README 位于 ZIP 内部，上传的是单个 ZIP 文件）。
3. 用浏览器进入仓库，选 Add file → Create new file。文件名输入 `.github/workflows/build.yml`，复制本项目自带的 `build.yml` 文件内容粘贴并提交。
4. Actions → Build ZY AI APK → Run workflow。或提交两个文件后自动触发。
5. 工作流成功后，在 Actions 本次运行最下面的 Artifacts 下载 `ZY-AI-debug-apk.zip`，解压得到 `app-debug.apk`。
6. 安装后进入设置，填写 API URL、模型、API Key；保存后输入消息测试。

注：默认地址 `https://api.openai.com/v1/chat/completions`、示例模型 `gpt-4o-mini`，仅当账号具有相应接口访问权限时有效。其他服务商请用其实际地址/模型；不要把私钥提交到 GitHub。

这是调试 APK，使用 GitHub Actions 构建；未进行真实服务商 API 联调。
